﻿using System;
using System.Reactive.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace _3a_CombineWith
{
    internal class Program
    {
        

        private static void Main(string[] args)
        {
            var input1 = GetInputStream(0);
            var input2 = GetInputStream(1);
            var d = input1.CombineLatest(input2, (i1, i2) => Tuple.Create(i1, i2, i1 && i2))
                .Subscribe(t => Console.WriteLine("input1: {0}, input2: {1}, output: {2}", t.Item1, t.Item2, t.Item3));
            Console.ReadLine();
            d.Dispose();
        }

        private static IObservable<bool> GetInputStream(int i)
        {
            return Observable.Create<bool>((ob, token) =>
            {
                Task task = Task.Factory.StartNew(() =>
                {
                    var random = new Random(Environment.TickCount + i * 10000);
                    while (!token.IsCancellationRequested)
                    {
                        bool value = random.Next(100)%2 == 0;
                        ob.OnNext(value);
                        Thread.Sleep(TimeSpan.FromMilliseconds(500 + i*10));
                    }
                    ob.OnCompleted();
                }, token);
                return task;
            });
        }
    }
}