﻿using System.Collections.Generic;
using System.ComponentModel;

namespace _8_NameCompletion_Done
{
    public class ViewModel : INotifyPropertyChanged
    {
        private IList<string> _names;


        public IList<string> Names
        {
            get { return _names; }
            set
            {
                if (Equals(value, _names)) return;
                _names = value;
                OnPropertyChanged("Names");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;


        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null) handler(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}