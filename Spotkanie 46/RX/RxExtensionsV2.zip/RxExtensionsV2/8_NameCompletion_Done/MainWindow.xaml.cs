﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive;
using System.Reactive.Concurrency;
using System.Reactive.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace _8_NameCompletion_Done
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private DataProvider _dataProvider;

        public MainWindow()
        {
            _dataProvider = new DataProvider();
            InitializeComponent();
            DataContext = new ViewModel();
            Observable.FromEventPattern<TextChangedEventHandler, TextChangedEventArgs>(
                h => _input.TextChanged += h,
                h => _input.TextChanged -= h)                
                .Select(eArgs => _input.Text)
                //.Throttle(TimeSpan.FromMilliseconds(200))
                .Select(_dataProvider.GetSuggestionsObservable)
                .Switch()                
                .SubscribeOn(TaskPoolScheduler.Default)
                .ObserveOn(new DispatcherSynchronizationContext())
                .Subscribe(OnNext);
        }

        private void OnNext(IList<string> suggestions)
        {
            ViewModel.Names = suggestions;
        }

        private ViewModel ViewModel
        {
            get
            {
                return (ViewModel)DataContext;
            }
        }
    }
}
