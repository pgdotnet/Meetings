﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reactive.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace _8_NameCompletion_Done
{
    public class DataProvider
    {
        private readonly List<string> _allNames;
        private readonly Random _random;

        public DataProvider()
        {
            _random = new Random();
            _allNames = File.ReadAllLines("imiona.csv")
                .Select(x => x.Split(';'))
                .Select(x => x[0])
                .Select(x => x.Replace("\"", String.Empty))
                .ToList();
        }

        public IObservable<IList<string>> GetSuggestionsObservable(string start)
        {
            return Observable.Create<IList<string>>((ob, cancellationToken) =>
            {
                Task task = Task.Factory.StartNew(() =>
                {
                    string term = start.ToLower();
                    Debug.WriteLine("Starting search for " + term);
                    var results = new List<string>();
                    bool found = false;
                    foreach (string name in _allNames)
                    {
                        if (cancellationToken.IsCancellationRequested)
                        {
                            Debug.WriteLine("Cancelling search for " + term);
                            break;
                        }
                        if (name.ToLower().StartsWith(term))
                        {
                            found = true;
                            results.Add(name);
                        }
                        else
                        {
                            if (found)
                                break;
                        }
                        Thread.Sleep(_random.Next(0, 3));
                    }
                    ob.OnNext(results);
                    ob.OnCompleted();
                }, cancellationToken);
                return task;
            });
        }
    }
}