﻿using System;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using Microsoft.Reactive.Testing;

namespace _5_Testing
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            var ts = new TestScheduler();
            TimerTest(ts);
            //ObservableTest(ts);
        }

        private static void ObservableTest(TestScheduler ts)
        {
            Observable.Create<int>(ob =>
            {
                Console.WriteLine("Subskrypcja");
                ob.OnNext(1);
                ob.OnCompleted();
                return Disposable.Empty;
            }).SubscribeOn(ts)
                .ObserveOn(ts)
                .Subscribe(x => Console.WriteLine("Obserwacja"));

            ts.Start();
            //Console.ReadLine();
            //ts.AdvanceBy(1);
            //Console.ReadLine();
            //ts.AdvanceBy(1);
            Console.ReadLine();
        }

        private static void TimerTest(TestScheduler ts)
        {
            Observable.Interval(TimeSpan.FromSeconds(1), ts).Subscribe(x => Console.WriteLine("Obserwacja"));

            ts.Start();            

            while (true)
            {
                ts.AdvanceBy(TimeSpan.FromSeconds(1).Ticks);
                Console.ReadLine();
            }
        }
    }
}