﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Threading;
using zzNameCompletion.Annotations;

namespace zzNameCompletion
{
    public class ViewModel : INotifyPropertyChanged
    {
        private IList<string> _names;
        private readonly List<string> _allNames;
        private Random _random;

        public ViewModel()
        {
            
        }


        public IList<string> Names
        {
            get { return _names; }
            set
            {
                if (Equals(value, _names)) return;
                _names = value;
                OnPropertyChanged("Names");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;        


        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null) handler(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}