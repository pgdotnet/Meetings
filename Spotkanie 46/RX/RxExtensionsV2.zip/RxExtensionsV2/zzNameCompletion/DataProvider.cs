﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using zzNameCompletion.Annotations;

namespace zzNameCompletion
{
    public class DataProvider
    {
        private readonly List<string> _allNames;
        private readonly Random _random;

        public DataProvider()
        {
            _random = new Random();
            _allNames = File.ReadAllLines("imiona.csv")
                .Select(x => x.Split(';'))
                .Select(x => x[0])
                .Select(x => x.Replace("\"", String.Empty))
                .ToList();
        }

        public IList<string> GetSuggestions(string start)
        {
            string term = start.ToLower();
            var results = new List<string>();
            bool found = false;
            foreach (string name in _allNames)
            {
                if (name.ToLower().StartsWith(term))
                {
                    found = true;
                    results.Add(name);
                }
                else
                {
                    if (found)
                        break;
                }
                Thread.Sleep(_random.Next(0, 3));
            }
            return results;
        }
    }
}