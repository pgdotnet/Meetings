﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace zzNameCompletion
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly DataProvider _dataProvider = new DataProvider();

        public MainWindow()
        {
            InitializeComponent();
            DataContext = new ViewModel();
            _input.TextChanged += InputOnTextChanged;
        }

        private void InputOnTextChanged(object sender, TextChangedEventArgs textChangedEventArgs)
        {
            string fullText = _input.Text;
            var suggestions = _dataProvider.GetSuggestions(fullText);
            ViewModel.Names = suggestions;
        }

        private ViewModel ViewModel
        {
            get
            {
                return (ViewModel) DataContext;
            }
        }
    }
}
