﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace _2_TworzenieObservabli
{
    class Program
    {
        static void Main(string[] args)
        {
            IObservable<int> source = null;
            IDisposable subscription = null;

            #region Proste metody

            //source = Observable.Return(10);
            //source = Observable.Never<int>();
            //source = Observable.Throw<int>(new Exception("ZLOOO"));
            //source = Observable.Repeat(10);            

            #endregion

            #region Zlozony przyklad

            //source = GetIteratingObservable();
            //source = GetIteratingObservableWithDisposable();
            source = GetCancelableIteratingObservable();

            #endregion

            subscription = source.Subscribe(
                x => Console.WriteLine("Dostalem wartosc: " + x), 
                ex => Console.WriteLine(ex), 
                () => Console.WriteLine("Strumien sie skonczyl!"));


            Console.ReadLine();
            Console.WriteLine("Zwalniam subskrypcje");
            if (subscription != null)
                subscription.Dispose();
            Console.ReadLine();
        }

        private static IObservable<int> GetIteratingObservable()
        {
            return Observable.Create<int>(ob =>
            {
                for (int i = 0; i < 10; i ++)
                {
                    ob.OnNext(i);
                }
                ob.OnCompleted();
                return Disposable.Create(() => Console.WriteLine("OOOOO"));
                //return Disposable.Empty;
            });
        }

        private static IObservable<int> GetIteratingObservableWithDisposable()
        {
            return Observable.Create<int>(ob =>
            {
                Task.Factory.StartNew(() =>
                {
                    for (int i = 0; i < 10; i++)
                    {
                        Console.WriteLine("Produkuje: " + i);
                        ob.OnNext(i);
                        Thread.Sleep(200);
                    }
                    ob.OnCompleted();
                });
                
                return Disposable.Create(() => Console.WriteLine("Hej! zwolniji mnie"));
            });
        }

        private static IObservable<int> GetCancelableIteratingObservable()
        {
            return Observable.Create<int>((IObserver<int> ob, CancellationToken token) =>
            {
                var task = Task.Factory.StartNew(() =>
                {
                    for (int i = 0; i < 10; i++)
                    {
                        if (token.IsCancellationRequested)
                            break;
                        Console.WriteLine("Produkuje: " + i);
                        ob.OnNext(i);
                        Thread.Sleep(200);
                    }
                    ob.OnCompleted();
                }, token);

                return task;
            });
        }

    }
}
