﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive.Concurrency;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using System.Text;
using System.Threading;

namespace _3c_Buffer
{
    class Program
    {
        private static Random _random = new Random();
        static void Main(string[] args)
        {
            var d = Generate()
                .Buffer(TimeSpan.FromSeconds(1), 10)
                .Subscribe(x => Console.WriteLine(string.Join("Liczba elementow: {0}", x.Count)));
            Console.ReadLine();
            d.Dispose();
        }

        static IObservable<int> Generate()
        {
            return Observable.Create<int>((ob) =>
            {
                for (int i = 0; i < 100000; i++)
                {
                    ob.OnNext(i);
                    Thread.Sleep(_random.Next(75, 126));
                }
                ob.OnCompleted();
                return Disposable.Empty;
            }).SubscribeOn(TaskPoolScheduler.Default);
        }
    }
}
