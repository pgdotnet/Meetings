﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reactive.Concurrency;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using System.Text;
using System.Threading;

namespace _4_MultiThreading
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Id watka glownego: {0}", Thread.CurrentThread.ManagedThreadId);
            ObservableTest();
            //TimerTest();
                Console.ReadLine();

            
        }

        private static void TimerTest()
        {
            Observable.Interval(TimeSpan.FromSeconds(1), ImmediateScheduler.Instance)
                .Subscribe(x => Console.WriteLine("Id watka obserwacji: {0}, wartosc: {1}", Thread.CurrentThread.ManagedThreadId, x));
        }

        private static void ObservableTest()
        {
            var ob = Generate().Publish().RefCount();
            ob
                .SubscribeOn(TaskPoolScheduler.Default)
                .ObserveOn(TaskPoolScheduler.Default)
                .Subscribe(x => Console.WriteLine("Id watka obserwacji: {0}, wartosc: {1}", Thread.CurrentThread.ManagedThreadId, x));
            Thread.Sleep(1000);

            ob
                .SubscribeOn(TaskPoolScheduler.Default)
                .ObserveOn(TaskPoolScheduler.Default)
                .Subscribe(x => Console.WriteLine("XXXXXId watka obserwacji: {0}, wartosc: {1}", Thread.CurrentThread.ManagedThreadId, x));
        }

        static IObservable<int> Generate()
        {
            return Observable.Create<int>(ob =>
            {
                Console.WriteLine("Id watka subskrypcji: {0}", Thread.CurrentThread.ManagedThreadId);
                int i = 0;
                while (true)
                {
                    i++;
                    ob.OnNext(i);
                    Thread.Sleep(TimeSpan.FromSeconds(1));
                }
                ob.OnCompleted();
                return Disposable.Empty;
            });
        }
    }
}
