﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reactive.Linq;
using System.Text;

namespace RxExtensionsV2
{
    class Program
    {
        static void Main(string[] args)
        {

            var observable = Enumerable.Range(1, 10).ToObservable();
            observable.Subscribe(new MyObserver());

            Console.ReadLine();
        }
    }

    public class MyObserver : IObserver<int>
    {
        public void OnNext(int value)
        {
            Console.WriteLine(value);
        }

        public void OnError(Exception error)
        {
            Console.WriteLine(error);
        }

        public void OnCompleted()
        {
            Console.WriteLine("DONE!");
        }
    }
}
