﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive.Concurrency;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace _3b_MergeSwitch
{
    class Program
    {
        static void Main(string[] args)
        {
            var obs = Observable.Interval(TimeSpan.FromMilliseconds(1000))                
                .Zip(Observable.Generate(0, s => s < 100, s => s+1, s => s), (i, l) => l)
                .SubscribeOn(TaskPoolScheduler.Default)
                .Select(GetSequence)
                .Merge()
                //.Concat()
                //.Switch()                
                .Subscribe(Console.WriteLine);

            Console.ReadLine();
            obs.Dispose();
        }

        static IObservable<int> GetSequence(int i)
        {
            return Observable.Create<int>((ob, token) =>
            {
                var task = Task.Factory.StartNew(() =>
                {
                    var startingPosition = i*100;
                    Console.WriteLine("Rozpoczeto: {0}", i);
                    for (int j = 0; j < 10; j++)
                    {
                        if (token.IsCancellationRequested)
                        {
                            Console.WriteLine("Zwolniono: {0}", i);
                            break;
                        }
                        ob.OnNext(startingPosition + j);
                        Thread.Sleep(400);
                    }
                    ob.OnCompleted();
                }, token);
                return task;
            });
        }
    }
}
