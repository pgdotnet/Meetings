﻿using System;
using System.Collections.Generic;
using MvvmTestability.Contracts;

namespace MvvmTestability.Models
{
    public interface IBeerService
    {
        IObservable<ICollection<Beer>> GetBeer();
    }
}