﻿using Faker;
using FizzWare.NBuilder;
using MvvmTestability.Contracts;
using System;
using System.Collections.Generic;
using System.Reactive.Linq;

namespace MvvmTestability.Models
{
	public class BeerService : IBeerService
	{
		public IObservable<ICollection<Beer>> GetBeer()
		{
			var random = new Random();
			var result = Builder<Beer>
				.CreateListOfSize(RandomNumber.Next(10, 20))
				.All()
					.With(b => b.Name = Company.Name())
					.With(b => b.Voltage = Math.Round(random.NextDouble() * 10, 1))
				.Build();

			return Observable.Return(result).Delay(TimeSpan.FromSeconds(3));
		}
	}
}