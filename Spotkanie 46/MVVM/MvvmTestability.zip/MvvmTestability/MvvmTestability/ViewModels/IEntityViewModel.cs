﻿namespace MvvmTestability.ViewModels
{
	public interface IEntityViewModel<TEntity> where TEntity : class, new()
	{
		TEntity DataObject { get; set; }
	}
}