﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows.Input;
using Microsoft.Practices.Prism.Commands;
using MvvmTestability.Controllers;

namespace MvvmTestability.ViewModels
{
	public class MainWindowViewModel : IMainWindowViewModel
	{
		private IMainWindowController _controller;

		public ICollection<IBeerViewModel> MyBeer { get; private set; }

		public ICommand GetBeerCommand { get; private set; }

		public MainWindowViewModel(IMainWindowController controller)
		{
			_controller = controller;
			_controller.ViewModel = this;

			MyBeer = new ObservableCollection<IBeerViewModel>();
			GetBeerCommand = new DelegateCommand(_controller.OnGetBeer);
		}
	}
}