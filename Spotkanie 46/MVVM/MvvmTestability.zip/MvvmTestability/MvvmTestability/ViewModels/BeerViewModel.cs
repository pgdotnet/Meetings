﻿using MvvmTestability.Contracts;

namespace MvvmTestability.ViewModels
{
	public class BeerViewModel : EntityViewModel<Beer>, IBeerViewModel
	{
		private string _name;

		public string Name
		{
			get { return _name; }
			set { SetProperty(ref _name, value); }
		}

		private double _voltage;

		public double Voltage
		{
			get { return _voltage; }
			set { SetProperty(ref _voltage, value); }
		}

		public BeerViewModel(Beer beer)
			: base(beer)
		{
			Name = beer.Name;
			Voltage = beer.Voltage;
		}
	}
}