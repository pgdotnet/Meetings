﻿namespace MvvmTestability.ViewModels
{
	public interface IBeerViewModel
	{
		string Name { get; set; }

		double Voltage { get; set; }
	}
}