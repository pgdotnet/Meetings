﻿using Microsoft.Practices.Prism.Mvvm;

namespace MvvmTestability.ViewModels
{
	public class EntityViewModel<TEntity> : BindableBase, IEntityViewModel<TEntity> where TEntity : class, new()
	{
		public TEntity DataObject { get; set; }

		public EntityViewModel(TEntity entity)
		{
			DataObject = entity;
		}
	}
}