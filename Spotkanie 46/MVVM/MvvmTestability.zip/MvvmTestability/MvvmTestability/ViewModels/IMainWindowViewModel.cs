﻿using System.Collections.Generic;
using System.Windows.Input;

namespace MvvmTestability.ViewModels
{
	public interface IMainWindowViewModel
	{
		ICollection<IBeerViewModel> MyBeer { get; }

		ICommand GetBeerCommand { get; }
	}
}