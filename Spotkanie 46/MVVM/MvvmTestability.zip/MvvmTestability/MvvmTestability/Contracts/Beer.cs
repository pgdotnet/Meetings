﻿namespace MvvmTestability.Contracts
{
	public class Beer
	{
		public string Name { get; set; }
		public double Voltage { get; set; }
	}
}
