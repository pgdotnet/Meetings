﻿using System.Windows;
using Microsoft.Practices.Unity;
using MvvmTestability.Controllers;
using MvvmTestability.Models;
using MvvmTestability.ViewModels;
using MvvmTestability.Views;

namespace MvvmTestability
{
	/// <summary>
	/// Interaction logic for App.xaml
	/// </summary>
	public partial class App : Application
	{
		protected override void OnStartup(StartupEventArgs e)
		{
			base.OnStartup(e);

			var container = new UnityContainer();

			container.RegisterType<IBeerService, BeerService>();
			container.RegisterType<IMainWindowController, MainWindowController>();
			container.RegisterType<IMainWindowViewModel, MainWindowViewModel>();
			container.RegisterType<IBeerViewModel, BeerViewModel>();

			var window = container.Resolve<MainWindow>();
			window.Show();
		}
	}
}