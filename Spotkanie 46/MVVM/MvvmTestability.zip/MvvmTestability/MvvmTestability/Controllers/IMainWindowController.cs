﻿using MvvmTestability.ViewModels;

namespace MvvmTestability.Controllers
{
	public interface IMainWindowController
	{
		MainWindowViewModel ViewModel { get; set; }

		void OnGetBeer();
	}
}