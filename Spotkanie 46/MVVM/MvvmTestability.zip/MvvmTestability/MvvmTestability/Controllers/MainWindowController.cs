﻿using System;
using System.Collections.Generic;
using System.Reactive.Concurrency;
using System.Reactive.Linq;
using Microsoft.Practices.ObjectBuilder2;
using Microsoft.Practices.Unity;
using MvvmTestability.Contracts;
using MvvmTestability.Models;
using MvvmTestability.ViewModels;

namespace MvvmTestability.Controllers
{
	public class MainWindowController : IMainWindowController
	{
		private readonly IUnityContainer _container;
		private readonly IBeerService _service;

		public MainWindowViewModel ViewModel { get; set; }

		public MainWindowController(IUnityContainer container, IBeerService service)
		{
			_container = container;
			_service = service;
		}

		public void OnGetBeer()
		{
			_service.GetBeer().SubscribeOn(TaskPoolScheduler.Default).ObserveOnDispatcher().Subscribe(OnBeerArrived);
		}

		private void OnBeerArrived(ICollection<Beer> myBeer)
		{
			ViewModel.MyBeer.Clear();
			myBeer.ForEach(b => ViewModel.MyBeer.Add(_container.Resolve<IBeerViewModel>(new ParameterOverride("beer", b))));
		}
	}
}