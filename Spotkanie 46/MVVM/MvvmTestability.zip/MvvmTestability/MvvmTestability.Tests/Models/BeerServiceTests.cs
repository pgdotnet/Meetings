﻿using MvvmTestability.Models;
using NUnit.Framework;

namespace MvvmTestability.Tests.Models
{
    [TestFixture]
    public class BeerServiceTests
    {
        [Test]
        public void GetBeer_Should_Return_Observable()
        {
            IBeerService sut = new BeerService();
            
            var result = sut.GetBeer();

            Assert.IsNotNull(result);
        }
    }
}