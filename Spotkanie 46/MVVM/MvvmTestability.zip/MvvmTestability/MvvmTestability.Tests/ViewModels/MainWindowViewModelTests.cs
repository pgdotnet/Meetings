﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Practices.Unity;
using Moq;
using MvvmTestability.Controllers;
using MvvmTestability.ViewModels;
using NUnit.Framework;

namespace MvvmTestability.Tests.ViewModels
{
	[TestFixture]
	public class MainWindowViewModelTests
	{
		private UnityContainer _container;
		private Mock<IMainWindowController> _controllerMock;

		[SetUp]
		public void SetUp()
		{
			_container = new UnityContainer();

			_container.RegisterType<IMainWindowViewModel, MainWindowViewModel>();

			_controllerMock = new Mock<IMainWindowController>();
			_container.RegisterInstance<IMainWindowController>(_controllerMock.Object);
		}

		[Test]
		public void CanBeConstructed()
		{
			_container.Resolve<IMainWindowViewModel>();
			Assert.Pass();
		}

		[Test]
		public void IsCommandSet()
		{
			var sut = _container.Resolve<IMainWindowViewModel>();

			Assert.IsNotNull(sut.GetBeerCommand);
		}
	}
}
