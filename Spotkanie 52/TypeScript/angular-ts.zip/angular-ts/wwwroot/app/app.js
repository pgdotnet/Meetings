/// <reference path="datectrl.ts" />
define(["require", "exports", 'angular', "DateCtrl"], function (require, exports, angular, dateCtrl) {
    var app = angular.module('dateExample', [])
        .controller('dateCtrl', dateCtrl.DateCtrl);
});
//# sourceMappingURL=app.js.map