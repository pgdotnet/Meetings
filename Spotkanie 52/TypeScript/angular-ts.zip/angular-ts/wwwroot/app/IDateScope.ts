﻿/// <reference path="../../typings/angular.d.ts" />

interface IDateScope extends ng.IScope {
    currentDate: Date;
    nextDayDate: Date;
    vm: IDateCtrl;
}