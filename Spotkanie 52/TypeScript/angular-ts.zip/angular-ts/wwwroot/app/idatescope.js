/// <reference path="../../typings/angular.d.ts" />
//# sourceMappingURL=idatescope.js.map