﻿/// <reference path="../../typings/angular.d.ts" />
/// <reference path="idatescope.ts" />
/// <reference path="../../typings/moment.d.ts" />

import moment = require('moment');

export class DateCtrl implements IDateCtrl {
    public static $inject = ['$scope'];

    constructor(private $scope: IDateScope) {
        this.$scope.currentDate = new Date();
        this.updateDate(this.$scope.currentDate);
        this.$scope.vm = this; 
    }   

    onDateChanged() {
        this.updateDate(this.$scope.currentDate);
    }

    private updateDate(date: Date) {
        var d = moment(date);
        d.add(1, "day");
        this.$scope.nextDayDate = d.toDate();
    }
}