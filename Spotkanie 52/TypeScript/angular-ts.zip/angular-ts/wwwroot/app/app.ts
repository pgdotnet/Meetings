﻿/// <reference path="datectrl.ts" />

import angular = require('angular');
import dateCtrl = require("DateCtrl");

var app = angular.module('dateExample', [])
    .controller('dateCtrl', dateCtrl.DateCtrl);