﻿/// <reference path="../../typings/require.d.ts" />

requirejs.config({
    paths: {
        angular: '../lib/angular/angular.min',
        jquery: '../lib/jquery/dist/jquery.min',
        moment: '../lib/momentjs/min/moment.min'
    },
    shim: {
        angular: {
            exports: 'angular',
            deps: ['jquery']
        }
    }
});

require(['angular', 'app'], () => {   
    angular.bootstrap(document, ['dateExample']);
})