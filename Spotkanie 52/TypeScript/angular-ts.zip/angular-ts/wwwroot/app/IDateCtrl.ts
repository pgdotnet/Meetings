﻿interface IDateCtrl {
    onDateChanged(): void;
}