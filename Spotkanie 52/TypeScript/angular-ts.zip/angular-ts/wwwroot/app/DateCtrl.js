/// <reference path="../../typings/angular.d.ts" />
/// <reference path="idatescope.ts" />
/// <reference path="../../typings/moment.d.ts" />
define(["require", "exports", 'moment'], function (require, exports, moment) {
    var DateCtrl = (function () {
        function DateCtrl($scope) {
            this.$scope = $scope;
            this.$scope.currentDate = new Date();
            this.updateDate(this.$scope.currentDate);
            this.$scope.vm = this;
        }
        DateCtrl.prototype.onDateChanged = function () {
            this.updateDate(this.$scope.currentDate);
        };
        DateCtrl.prototype.updateDate = function (date) {
            var d = moment(date);
            d.add(1, "day");
            this.$scope.nextDayDate = d.toDate();
        };
        DateCtrl.$inject = ['$scope'];
        return DateCtrl;
    })();
    exports.DateCtrl = DateCtrl;
});
//# sourceMappingURL=DateCtrl.js.map