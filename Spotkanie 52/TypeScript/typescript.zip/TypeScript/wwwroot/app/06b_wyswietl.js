define(["require", "exports"], function (require, exports) {
    var Wyswietl = (function () {
        function Wyswietl() {
        }
        Wyswietl.prototype.wyswietl = function (msg) {
            alert(msg);
        };
        return Wyswietl;
    })();
    exports.Wyswietl = Wyswietl;
});
//# sourceMappingURL=06b_wyswietl.js.map