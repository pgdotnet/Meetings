﻿/// <reference path="../../scripts/typings/require.d.ts" />
//konfiguracja requirejs 


/*
requirejs.config({
    paths: {
        moment: '../lib/momentjs/moment'
    },
    shim: {
        //moment: ['jquery']
    }
});

require(["06_requirejs"]);
*/