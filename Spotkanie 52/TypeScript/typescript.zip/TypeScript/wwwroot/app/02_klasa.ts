﻿//klasa punkt z metoda, ktora drukuje X i Y

//klasa Samochod z getterem/setterem marka

/*
class Punkt {
    x: number;
    y: number;

    constructor(x: number, y: number) {
        this.x = x;
        this.y = y;
    }

    displayDetails() {
        alert(`X: ${this.x} Y: ${this.x}`);
    }
}

var p: Punkt = new Punkt(1, 2);
p.displayDetails();
*/

/*

class Samochod {
    private _marka: string;

    get marka(): string {
        return this._marka;
    }

    set marka(value: string) {
        this._marka = value;
    }
}

var s: Samochod = new Samochod();
s.marka = "Ford";
alert(`Marka samochod to ${s.marka}`);
*/