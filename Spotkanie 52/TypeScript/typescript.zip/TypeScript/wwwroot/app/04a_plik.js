//klasa Wyswietl z metoda wyswietl 
/*
class Wyswietl {
    wyswietl(msg: string) {
        alert(msg);
    }
}
*/ 
//# sourceMappingURL=04a_plik.js.map