﻿

//interfejs punkt + klasa implementujaca interfejs (ducktyping)


//interfejs zwierzatko, z metoda wydajDzwiek



/*
interface IPunkt {
    x: number;
    y: number;
}


class Punkt implements IPunkt {
    x: number;
    y: number;
    
    constructor(x: number, y: number) {
        this.x = x;
        this.y = y;
    }

    obliczOdleglosc(punkt: IPunkt): number {
        return Math.sqrt(Math.pow((this.x - punkt.x), 2) + Math.pow((this.y - punkt.y), 2));
    }
}

var p1: Punkt = new Punkt(1, 1);
//var p2: Punkt = new Punkt(2, 2);
//var p2 = { x: 2, y: 2 };
//alert(p1.obliczOdleglosc(p2));
*/

/*
interface IZwierzatko {
    wydajDzwiek: (imie: string) => void;
}
*/