﻿export class Wyswietl {
    wyswietl(msg: string) {
        alert(msg);
    }
}