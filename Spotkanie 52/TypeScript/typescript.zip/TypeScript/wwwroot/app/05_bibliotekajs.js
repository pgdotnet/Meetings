/// <reference path="../../scripts/typings/moment.d.ts" />
var data = moment(new Date());
alert(data);
alert(data.add(1, "Day"));
//# sourceMappingURL=05_bibliotekajs.js.map