//klasa pozdrawiacz ktora ma metode pozdrow - korzysta z wyswietlacz
/*
class Pozdrawiacz {
    pozdrow(kto: string) {
        var w: Wyswietl = new Wyswietl();

        w.wyswietl(`Witaj ${kto}`);
    }
}

var p: Pozdrawiacz = new Pozdrawiacz();
p.pozdrow("Maciej");
*/ 
//# sourceMappingURL=04b_plik.js.map