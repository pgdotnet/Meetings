﻿//utworzenie aktualnej daty i wyswietlenie dnia nastepnego


/*
import moment = require('moment');
import wyswietl = require("06b_wyswietl");

var data = moment();
data.add(1, "day");
var w: wyswietl.Wyswietl = new wyswietl.Wyswietl();
w.wyswietl(data.format());
*/