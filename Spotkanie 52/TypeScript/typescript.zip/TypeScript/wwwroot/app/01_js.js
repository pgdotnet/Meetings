﻿// Kilka przykladow JS

/* 
 * var x = 1;
 * x = "string";
 * 
 * function sayHello(arg) {
 *  alert(arg);
 * }
 * 
 * sayHello(x);
 */

// klasy w JS
/*
function Klasa() {
    
}

Klasa.prototype.sayHello = function(x) {
    alert("Hello");
}

var klasa = new Klasa();
klasa.sayHello("JA");
*/