﻿/// <autosync enabled="true" />
/// <reference path="../gruntfile.js" />
/// <reference path="../wwwroot/app/01_js.js" />
/// <reference path="../wwwroot/app/02_klasa.js" />
/// <reference path="../wwwroot/app/03_interfejsy.js" />
/// <reference path="../wwwroot/app/04a_plik.js" />
/// <reference path="../wwwroot/app/04b_plik.js" />
/// <reference path="../wwwroot/app/config.js" />
